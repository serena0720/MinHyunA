//
//  JSONModel.swift
//  ServerJson_01
//
//  Created by Kenny on 2022/09/18.
//

struct StudentJSON: Codable{
    var code: String
    var phone: String
    var name: String
    var dept: String
}
